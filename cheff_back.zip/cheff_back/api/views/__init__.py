from .cbv import CategoryListAPIView, CategoryDetailAPIView,FavoriteAPIView
from .fbv import food_by_category, food_list,favorite, get_user_id, remove_from_favorites,add_to_favorites